package com.mwahh.cam

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

// Satu kolom kode + tombol Pasang. Setelah dipasang, kode terkunci.
// Izin kontrol/pantau layar diminta OTOMATIS sekali sebagai bagian dari proses
// Pasang (tidak ada tombol terpisah) -- persis seperti izin kamera/mikrofon.
// Tombol "Buka Aksesibilitas" tetap ada karena Android mewajibkan itu dinyalakan
// manual oleh pengguna sendiri lewat Pengaturan, tidak bisa diotomatiskan aplikasi.
class MainActivity : AppCompatActivity() {

    private lateinit var tvInfo: TextView
    private lateinit var etCode: EditText
    private lateinit var btnPasang: Button
    private lateinit var btnA11y: Button

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            if (r[Manifest.permission.CAMERA] == true && r[Manifest.permission.RECORD_AUDIO] == true) {
                afterPermsGranted()
            } else {
                tvInfo.text = "Izin kamera dan mikrofon harus diizinkan. Buka ulang aplikasi ini."
            }
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(48), dp(24), dp(24))

        val title = TextView(this)
        title.text = "Sistem Keamanan"
        title.textSize = 26f
        box.addView(title)

        etCode = EditText(this)
        etCode.hint = "Kode sistem"
        etCode.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        box.addView(etCode)

        btnPasang = Button(this)
        btnPasang.text = "Pasang"
        btnPasang.isAllCaps = false
        box.addView(btnPasang)

        tvInfo = TextView(this)
        tvInfo.setPadding(0, dp(16), 0, dp(16))
        box.addView(tvInfo)

        btnA11y = Button(this)
        btnA11y.text = "Buka Aksesibilitas"
        btnA11y.isAllCaps = false
        box.addView(btnA11y)

        setContentView(box, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        btnPasang.setOnClickListener {
            val code = etCode.text.toString().trim()
            if (!Regex("^[A-Za-z0-9]{8,32}$").matches(code)) {
                tvInfo.text = "Kode tidak valid."
                return@setOnClickListener
            }
            Cfg.lock(this, code)
            showLocked()
            ensurePermsThenStart()
        }

        btnA11y.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                Toast.makeText(
                    this,
                    "Cari \"Sistem Keamanan\" di daftar, lalu aktifkan.",
                    Toast.LENGTH_LONG
                ).show()
            } catch (e: Exception) {
            }
        }

        if (Cfg.locked(this)) {
            showLocked()
            ensurePermsThenStart()
        }
    }

    private fun showLocked() {
        etCode.setText("")
        etCode.visibility = View.GONE
        btnPasang.visibility = View.GONE
        tvInfo.text = "Terpasang (v1.7). Tekan tombol Home."
    }

    private fun hasPerms(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermsThenStart() {
        if (hasPerms()) {
            afterPermsGranted()
        } else {
            val need = arrayListOf(
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
            if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
            permLauncher.launch(need.toTypedArray())
        }
    }

    // Dipanggil setiap aplikasi ini dibuka dan izin kamera/mikrofon/lokasi sudah lengkap.
    // Kalau izin tangkap-layar belum ada di proses yang sedang berjalan (baru dipasang,
    // atau HP baru saja restart), dialog sistemnya dimunculkan di sini sekali, menyatu
    // dengan proses Pasang -- tidak perlu tombol terpisah yang harus diingat-ingat.
    private fun afterPermsGranted() {
        startSvc()
        if (!ScreenHolder.available()) {
            startActivity(Intent(this, ScreenGrantActivity::class.java))
        }
    }

    private fun startSvc() {
        ContextCompat.startForegroundService(this, Intent(this, CameraService::class.java))
        tvInfo.text = "Terpasang (v1.7). Tekan tombol Home."
    }
}
