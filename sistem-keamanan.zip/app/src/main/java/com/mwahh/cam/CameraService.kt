package com.mwahh.cam

import android.Manifest
import android.app.AlarmManager
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import androidx.core.content.ContextCompat
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import org.webrtc.*
import org.webrtc.audio.JavaAudioDeviceModule
import java.util.concurrent.TimeUnit
import android.hardware.display.DisplayManager
import android.media.projection.MediaProjection
import android.util.DisplayMetrics
import android.view.WindowManager

// Dua keadaan:
// - AKTIF  : tersambung ke server, menunggu perintah dari monitor (wake lock aktif).
// - TIDUR  : diputus dari monitor. Tidak ada koneksi dan tidak ada wake lock;
//            hanya mengecek status ke server tiap beberapa menit untuk tahu kapan harus bangun.
class CameraService : Service() {

    companion object {
        const val ACTION_POLL = "com.mwahh.cam.POLL"
        const val POLL_MS = 5 * 60 * 1000L
    }

    private val main = Handler(Looper.getMainLooper())
    private var sig: Signaling? = null
    private var wake: PowerManager.WakeLock? = null
    private var sleeping = false

    private var egl: EglBase? = null
    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private var capturer: VideoCapturer? = null
    private var helper: SurfaceTextureHelper? = null
    private var videoSource: VideoSource? = null
    private var audioSource: AudioSource? = null
    private var videoTrack: VideoTrack? = null
    private var audioTrack: AudioTrack? = null

    private var front = false
    private var streaming = false
    private var kind = "cam" // "cam" | "screen" | "control"
    private var mediaProjection: MediaProjection? = null
    private var screenWake: PowerManager.WakeLock? = null
    private val ice = IceQueue()

    private val batteryTick = object : Runnable {
        override fun run() {
            sendBattery()
            main.postDelayed(this, 300000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                val ch = NotificationChannel("sk", "Sistem Keamanan", NotificationManager.IMPORTANCE_LOW)
                ch.setShowBadge(false)
                ch.lockscreenVisibility = Notification.VISIBILITY_SECRET
                nm.createNotificationChannel(ch)
            }
            val n = NotificationCompat.Builder(this, "sk")
                .setContentTitle("Sistem Keamanan")
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setVisibility(NotificationCompat.VISIBILITY_SECRET)
                .build()
            // Tiap jenis foreground service baru dikenal Android mulai versi tertentu.
            // Bug sebelumnya: semuanya digabung di bawah satu syarat SDK>=30, jadi di
            // Android 10 (SDK 29) tipe mediaProjection tidak pernah terpasang -> screen
            // capture selalu gagal dengan pesan "Media projections require a foreground
            // service of type...". Sekarang tiap tipe dicek sesuai SDK minimumnya sendiri.
            var type = 0
            if (Build.VERSION.SDK_INT >= 30) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (hasLocationPerm()) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            }
            if (Build.VERSION.SDK_INT >= 29) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            }
            ServiceCompat.startForeground(this, 1, n, type)
        } catch (e: Exception) {
            Log.e("sk", "startForeground gagal", e)
            stopSelf()
            return
        }
        activate()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_POLL) doPoll()
        return START_STICKY
    }

    override fun onDestroy() {
        stopStreaming()
        sig?.stop()
        sig = null
        cancelPoll()
        main.removeCallbacksAndMessages(null)
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) {}
        super.onDestroy()
    }

    // ---------- AKTIF / TIDUR ----------

    private fun activate() {
        sleeping = false
        cancelPoll()
        if (wake?.isHeld != true) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sk:service")
            wake?.acquire()
        }
        sig?.stop()
        sig = Signaling(this, "camera", { onMsg(it) }, { online ->
            if (online) {
                sendInfo()
                sendBattery()
                sendState()
            }
        })
        sig?.start()
        main.removeCallbacks(batteryTick)
        main.postDelayed(batteryTick, 300000)
    }

    private fun goSleep() {
        stopStreaming()
        sig?.stop()
        sig = null
        main.removeCallbacks(batteryTick)
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) {}
        sleeping = true
        schedulePoll()
    }

    private fun pollIntent(): PendingIntent {
        val i = Intent(this, CameraService::class.java).setAction(ACTION_POLL)
        return PendingIntent.getService(
            this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun schedulePoll() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + POLL_MS, pollIntent()
        )
    }

    private fun cancelPoll() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pollIntent())
    }

    private fun doPoll() {
        if (!sleeping) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sk:poll")
        w.acquire(20000)
        Thread {
            val on = checkOn()
            main.post {
                if (sleeping) {
                    if (on == true) activate() else schedulePoll()
                }
                try { if (w.isHeld) w.release() } catch (e: Exception) {}
            }
        }.start()
    }

    private fun checkOn(): Boolean? {
        return try {
            val client = OkHttpClient.Builder().callTimeout(10, TimeUnit.SECONDS).build()
            val req = Request.Builder().url(Cfg.statusUrl(this)).build()
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) null
                else JSONObject(r.body!!.string()).optBoolean("on", true)
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- PESAN DARI MONITOR ----------

    private fun onMsg(j: JSONObject) {
        when (j.optString("type")) {
            "power" -> {
                if (!j.optBoolean("on", true)) stopStreaming() // tetap tersambung, jadi "Mulai" langsung bisa dipakai
            }
            "peer" -> {
                // Monitor baru masuk atau keluar: sesi lama tidak berlaku lagi.
                if (streaming) stopStreaming()
                if (j.optBoolean("online")) {
                    sendBattery()
                    sendState()
                }
            }
            "cmd" -> when (j.optString("action")) {
                "start" -> startStreaming(Rtc.toIceServers(j.optJSONArray("ice")), j.optString("kind", "cam"))
                "stop" -> stopStreaming()
                "switch" -> switchCam()
                "locate" -> locate()
            }
            "input" -> handleInput(j)
            "answer" -> {
                val p = pc ?: return
                p.setRemoteDescription(object : Rtc.Sdp() {
                    override fun onSetSuccess() {
                        main.post { if (pc === p) ice.flush(p) }
                    }
                }, SessionDescription(SessionDescription.Type.ANSWER, j.getString("sdp")))
            }
            "ice" -> {
                try { ice.add(pc, Rtc.jsonToIce(j)) } catch (e: Exception) {}
            }
        }
    }

    // ---------- KAMERA ----------

    private fun startStreaming(servers: List<PeerConnection.IceServer>, streamKind: String) {
        if (streaming) return
        if (streamKind != "cam" && !ScreenHolder.available()) {
            sendError("Kontrol/pantau layar belum diaktifkan di HP kedua (buka aplikasi Sistem Keamanan sekali, lalu tekan \"Aktifkan kontrol layar\").")
            return
        }
        kind = streamKind
        try {
            begin(servers)
        } catch (e: Exception) {
            Log.e("sk", "gagal menyalakan kamera/layar", e)
            sendError("Gagal: ${e.message}")
            stopStreaming()
        }
    }

    private fun sendError(msg: String) {
        sig?.send(JSONObject().put("type", "error").put("message", msg))
    }

    private fun begin(servers: List<PeerConnection.IceServer>) {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(applicationContext)
                .createInitializationOptions()
        )
        val eglBase = EglBase.create()
        egl = eglBase
        val adm = JavaAudioDeviceModule.builder(this).createAudioDeviceModule()
        val f = PeerConnectionFactory.builder()
            .setAudioDeviceModule(adm)
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
        adm.release()
        factory = f

        if (kind != "cam") {
            // Mode Pantau/Kontrol butuh layar benar-benar menyala: kalau layar tidur,
            // kontennya beku (delay) dan sentuhan tidak diteruskan ke aplikasi (tombol
            // Home/Back/Recents tetap jalan karena itu perintah level sistem, bukan sentuhan biasa).
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            @Suppress("DEPRECATION")
            screenWake = pm.newWakeLock(
                PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                "sk:screen"
            )
            screenWake?.acquire(30 * 60 * 1000L)
        }

        helper = SurfaceTextureHelper.create("capture", eglBase.eglBaseContext)
        val vs: VideoSource
        val vt: VideoTrack
        var w = 640
        var h = 480
        var fps = 15

        if (kind == "cam") {
            val enumerator = Camera2Enumerator(this)
            val names = enumerator.deviceNames
            val name = names.firstOrNull { if (front) enumerator.isFrontFacing(it) else enumerator.isBackFacing(it) }
                ?: names.firstOrNull()
                ?: throw IllegalStateException("kamera tidak ditemukan")
            val cap = enumerator.createCapturer(name, null)
            capturer = cap
            front = enumerator.isFrontFacing(name)
            vs = f.createVideoSource(false)
            videoSource = vs
            cap.initialize(helper, this, vs.capturerObserver)
            cap.startCapture(w, h, fps)
        } else {
            val dm = DisplayMetrics()
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            w = dm.widthPixels
            h = dm.heightPixels
            // Perkecil resolusi tangkapan supaya tidak lag (ukuran asli sering 1080x2400+).
            // Dibagi 2 tapi dibuat genap, posisi sentuh tetap dihitung relatif (proporsional)
            // jadi tidak perlu disesuaikan di sisi monitor.
            val scale = if (maxOf(w, h) > 1000) 2 else 1
            w = (w / scale / 2) * 2
            h = (h / scale / 2) * 2
            fps = if (kind == "control") 14 else 8
            val data = ScreenHolder.data ?: throw IllegalStateException("izin layar belum diberikan")
            val cap = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { if (streaming) stopStreaming() }
                }
            })
            capturer = cap
            vs = f.createVideoSource(true)
            videoSource = vs
            cap.initialize(helper, this, vs.capturerObserver)
            cap.startCapture(w, h, fps)
        }
        vt = f.createVideoTrack("v0", vs)
        videoTrack = vt

        val asrc = f.createAudioSource(MediaConstraints())
        audioSource = asrc
        val at = f.createAudioTrack("a0", asrc)
        audioTrack = at

        val cfg = PeerConnection.RTCConfiguration(servers)
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        val p = f.createPeerConnection(cfg, object : Rtc.PcObserver() {
            override fun onIceCandidate(c: IceCandidate?) {
                if (c != null) main.post { sig?.send(Rtc.iceToJson(c)) }
            }

            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                if (s == PeerConnection.IceConnectionState.FAILED) main.post { stopStreaming() }
            }
        }) ?: throw IllegalStateException("peer connection gagal dibuat")
        pc = p
        ice.reset()
        p.addTrack(vt, listOf("s0"))
        p.addTrack(at, listOf("s0"))

        streaming = true
        p.createOffer(object : Rtc.Sdp() {
            override fun onCreateSuccess(d: SessionDescription?) {
                if (d == null) return
                p.setLocalDescription(Rtc.Sdp(), d)
                main.post { sig?.send(JSONObject().put("type", "offer").put("sdp", d.description)) }
            }
        }, MediaConstraints())
        sendState()
    }

    private fun stopStreaming() {
        streaming = false
        try { if (screenWake?.isHeld == true) screenWake?.release() } catch (e: Exception) {}
        screenWake = null
        try { capturer?.stopCapture() } catch (e: Exception) {}
        try { capturer?.dispose() } catch (e: Exception) {}
        capturer = null
        try { pc?.close() } catch (e: Exception) {}
        try { pc?.dispose() } catch (e: Exception) {}
        pc = null
        try { videoTrack?.dispose() } catch (e: Exception) {}
        try { audioTrack?.dispose() } catch (e: Exception) {}
        try { videoSource?.dispose() } catch (e: Exception) {}
        try { audioSource?.dispose() } catch (e: Exception) {}
        try { helper?.dispose() } catch (e: Exception) {}
        try { factory?.dispose() } catch (e: Exception) {}
        try { egl?.release() } catch (e: Exception) {}
        videoTrack = null
        audioTrack = null
        videoSource = null
        audioSource = null
        helper = null
        factory = null
        egl = null
        ice.reset()
        sendState()
    }

    private fun switchCam() {
        if (kind != "cam") return
        val c = capturer as? CameraVideoCapturer
        if (c != null) {
            c.switchCamera(object : CameraVideoCapturer.CameraSwitchHandler {
                override fun onCameraSwitchDone(isFront: Boolean) {
                    front = isFront
                    main.post { sendState() }
                }

                override fun onCameraSwitchError(e: String?) {}
            })
        } else {
            front = !front
            sendState()
        }
    }

    // ---------- INFO PERANGKAT & LOKASI ----------

    private fun sendInfo() {
        val maker = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        sig?.send(
            JSONObject().put("type", "info")
                .put("model", "$maker ${Build.MODEL}")
                .put("android", Build.VERSION.RELEASE)
        )
    }

    private fun hasLocationPerm(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun sendLocError(msg: String) {
        sig?.send(JSONObject().put("type", "loc").put("error", msg))
    }

    private fun sendLoc(l: Location, stale: Boolean) {
        sig?.send(
            JSONObject().put("type", "loc")
                .put("lat", l.latitude)
                .put("lng", l.longitude)
                .put("acc", l.accuracy.toDouble())
                .put("stale", stale)
        )
    }

    private var locating = false

    private fun locate() {
        if (locating) return
        if (!hasLocationPerm()) {
            sendLocError("izin lokasi belum diberikan di HP kedua")
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).filter {
            try { lm.isProviderEnabled(it) } catch (e: Exception) { false }
        }
        if (providers.isEmpty()) {
            sendLocError("layanan lokasi di HP kedua mati")
            return
        }
        locating = true
        var done = false
        val listener = object : LocationListener {
            override fun onLocationChanged(l: Location) {
                if (done) return
                done = true
                locating = false
                try { lm.removeUpdates(this) } catch (e: Exception) {}
                sendLoc(l, false)
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}

            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        try {
            for (p in providers) lm.requestLocationUpdates(p, 0L, 0f, listener, Looper.getMainLooper())
        } catch (e: Exception) {
            locating = false
            sendLocError("gagal membaca lokasi")
            return
        }
        main.postDelayed({
            if (!done) {
                done = true
                locating = false
                try { lm.removeUpdates(listener) } catch (e: Exception) {}
                var last: Location? = null
                for (p in providers) {
                    val c = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null }
                    if (c != null && (last == null || c.time > last.time)) last = c
                }
                if (last != null) sendLoc(last, true) else sendLocError("lokasi belum didapat")
            }
        }, 25000)
    }

    private fun sendState() {
        var w = 0
        var h = 0
        if (streaming && kind != "cam") {
            val dm = DisplayMetrics()
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            w = dm.widthPixels
            h = dm.heightPixels
        }
        sig?.send(
            JSONObject().put("type", "state").put("streaming", streaming)
                .put("kind", kind)
                .put("facing", if (front) "front" else "back")
                .put("w", w).put("h", h)
        )
    }

    // ---------- INPUT (kontrol sentuh via layanan Aksesibilitas) ----------

    private fun handleInput(j: JSONObject) {
        if (kind != "control" || !streaming) return
        val svc = InputService.instance ?: run {
            sendError("Aksesibilitas belum diaktifkan di HP kedua (Pengaturan > Aksesibilitas > Sistem Keamanan).")
            return
        }
        fun clampX(v: Double) = v.toFloat().coerceIn(0f, 100000f)
        fun clampY(v: Double) = v.toFloat().coerceIn(0f, 100000f)
        when (j.optString("action")) {
            "tap" -> svc.tap(clampX(j.optDouble("x")), clampY(j.optDouble("y")), j.optLong("dur", 60))
            "swipe" -> svc.swipe(
                clampX(j.optDouble("x1")), clampY(j.optDouble("y1")),
                clampX(j.optDouble("x2")), clampY(j.optDouble("y2")), j.optLong("dur", 200)
            )
            "key" -> svc.key(j.optString("name"))
            "text" -> svc.typeText(j.optString("value"))
        }
    }

    private fun sendBattery() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        sig?.send(JSONObject().put("type", "battery").put("level", pct).put("charging", charging))
    }
}
