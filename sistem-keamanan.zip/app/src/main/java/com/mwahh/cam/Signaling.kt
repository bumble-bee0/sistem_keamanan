package com.mwahh.cam

import android.content.Context
import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

// Koneksi WebSocket ke Worker, otomatis menyambung ulang kalau putus.
class Signaling(
    private val ctx: Context,
    private val role: String,
    private val handler: (JSONObject) -> Unit,
    private val statusCb: (Boolean) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()
    private var ws: WebSocket? = null
    private var running = false
    private var retry = 0

    private val pinger = object : Runnable {
        override fun run() {
            ws?.send("ping")
            main.postDelayed(this, 30000)
        }
    }

    fun start() {
        running = true
        connect()
    }

    private fun connect() {
        if (!running) return
        val req = Request.Builder().url(Cfg.wsUrl(ctx)).build()
        ws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                main.post {
                    if (ws === webSocket) {
                        retry = 0
                        main.removeCallbacks(pinger)
                        main.postDelayed(pinger, 30000)
                        statusCb(true)
                    }
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text == "pong") return
                val j = try { JSONObject(text) } catch (e: Exception) { return }
                main.post { if (running && ws === webSocket) handler(j) }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                lost(webSocket)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                lost(webSocket)
            }
        })
    }

    private fun lost(w: WebSocket) {
        main.post {
            if (ws !== w) return@post
            ws = null
            main.removeCallbacks(pinger)
            statusCb(false)
            if (running) {
                retry++
                val wait = minOf(30000L, 2000L * retry)
                main.postDelayed({ connect() }, wait)
            }
        }
    }

    fun send(j: JSONObject) {
        ws?.send(j.toString())
    }

    fun stop() {
        running = false
        main.removeCallbacksAndMessages(null)
        ws?.close(1000, null)
        ws = null
    }
}
