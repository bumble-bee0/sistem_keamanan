package com.mwahh.cam

import android.content.Intent

// Menyimpan izin tangkap-layar (sekali diberikan) selama proses aplikasi masih hidup.
// Android mewajibkan izin ini diberikan lewat dialog sistem secara langsung di HP;
// tidak bisa diberikan dari jarak jauh. Kalau HP kedua restart atau prosesnya
// dimatikan sistem, izin ini perlu diberikan ulang sekali saat kamu di lokasi.
object ScreenHolder {
    @Volatile
    var data: Intent? = null

    fun available() = data != null

    fun set(resultData: Intent) {
        data = resultData
    }

    fun clear() {
        data = null
    }
}
