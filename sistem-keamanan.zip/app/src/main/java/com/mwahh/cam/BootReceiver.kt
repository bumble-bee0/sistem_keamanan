package com.mwahh.cam

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

// Menyalakan ulang CameraService otomatis setelah HP selesai restart, memakai izin
// yang sudah pernah diberikan user sebelumnya (izin tidak diminta ulang, tetap tersimpan
// oleh Android). Tanpa receiver ini, service baru jalan lagi kalau user membuka aplikasi
// secara manual dan menekan tombol Home.
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        // Kalau belum pernah dipasang (belum punya kode), tidak ada yang perlu dinyalakan.
        if (!Cfg.locked(context)) return
        try {
            ContextCompat.startForegroundService(context, Intent(context, CameraService::class.java))
        } catch (e: Exception) {
            // Dibiarkan diam: di sebagian HP (mis. restriksi pabrikan) start dari boot
            // bisa ditolak sistem; tidak ada yang bisa dilakukan selain lewat buka aplikasi manual.
        }
    }
}
