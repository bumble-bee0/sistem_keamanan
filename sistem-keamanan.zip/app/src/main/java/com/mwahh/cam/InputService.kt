package com.mwahh.cam

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

// Menjalankan sentuhan/tombol sistem atas perintah dari HP utama.
// Harus diaktifkan manual sekali di Pengaturan > Aksesibilitas.
class InputService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: InputService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    // onResult: true = sistem menerima & menjalankan gestur, false = ditolak/dibatalkan sistem.
    // Dipakai untuk mengirim status balik ke HP utama supaya kelihatan apakah masalahnya di
    // level sistem Android (ditolak) atau di aplikasi tujuan di HP kedua (diterima tapi tak berefek).
    fun tap(x: Float, y: Float, durMs: Long, onResult: (Boolean) -> Unit) {
        val p = Path()
        p.moveTo(x, y)
        // Nudge 1px: beberapa perangkat/OEM menolak path berpanjang nol sebagai gestur tap yang sah.
        p.lineTo(x + 1f, y)
        gesture(p, durMs, onResult)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durMs: Long, onResult: (Boolean) -> Unit) {
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        gesture(p, durMs, onResult)
    }

    private fun gesture(p: Path, durMs: Long, onResult: (Boolean) -> Unit) {
        val stroke = GestureDescription.StrokeDescription(p, 0, durMs.coerceAtLeast(1))
        val g = GestureDescription.Builder().addStroke(stroke).build()
        val dispatched = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onResult(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                onResult(false)
            }
        }, null)
        // dispatchGesture() sendiri bisa langsung mengembalikan false kalau gestur ditolak
        // seketika (tanpa sempat memanggil callback sama sekali).
        if (!dispatched) onResult(false)
    }

    fun key(name: String) {
        val action = when (name) {
            "home" -> GLOBAL_ACTION_HOME
            "back" -> GLOBAL_ACTION_BACK
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick" -> GLOBAL_ACTION_QUICK_SETTINGS
            "lock" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return
            else -> return
        }
        performGlobalAction(action)
    }

    fun typeText(s: String) {
        val node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        var cur = node.text?.toString() ?: ""
        if (Build.VERSION.SDK_INT >= 26 && node.isShowingHintText) cur = ""
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, cur + s)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }
}
