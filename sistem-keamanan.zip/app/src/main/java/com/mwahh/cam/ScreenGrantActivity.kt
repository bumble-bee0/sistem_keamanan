package com.mwahh.cam

import android.app.Activity
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

// Activity transparan: hanya memunculkan dialog izin tangkap-layar sekali,
// lalu menyimpan hasilnya ke ScreenHolder dan langsung menutup diri.
class ScreenGrantActivity : AppCompatActivity() {

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK && r.data != null) {
            ScreenHolder.set(r.data!!)
            Toast.makeText(this, "Kontrol/pantau layar aktif.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Dibatalkan, kontrol layar belum aktif.", Toast.LENGTH_LONG).show()
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        launcher.launch(mgr.createScreenCaptureIntent())
    }
}
