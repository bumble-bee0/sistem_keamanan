package com.mwahh.cam

import android.content.Context
import java.net.URLEncoder

object Cfg {
    const val HOST = "mwahh.mwahh.workers.dev"

    private fun prefs(c: Context) = c.getSharedPreferences("cam", Context.MODE_PRIVATE)

    fun code(c: Context): String = prefs(c).getString("code", "") ?: ""
    fun locked(c: Context): Boolean = prefs(c).getBoolean("locked", false) && code(c).isNotEmpty()

    // Sekali dipasang, kode terkunci (tidak ada tombol untuk mengubah).
    fun lock(c: Context, code: String) {
        prefs(c).edit().putString("code", code).putBoolean("locked", true).apply()
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun wsUrl(c: Context) = "wss://$HOST/ws?code=${enc(code(c))}&role=camera"
    fun statusUrl(c: Context) = "https://$HOST/status?code=${enc(code(c))}"
}
