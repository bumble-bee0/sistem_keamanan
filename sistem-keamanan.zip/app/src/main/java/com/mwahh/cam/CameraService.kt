package com.mwahh.cam

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import org.webrtc.*
import org.webrtc.audio.JavaAudioDeviceModule
import java.util.concurrent.TimeUnit

// Dua keadaan:
// - AKTIF  : tersambung ke server, menunggu perintah dari monitor (wake lock aktif).
// - TIDUR  : diputus dari monitor. Tidak ada koneksi dan tidak ada wake lock;
//            hanya mengecek status ke server tiap beberapa menit untuk tahu kapan harus bangun.
class CameraService : Service() {

    companion object {
        const val ACTION_POLL = "com.mwahh.cam.POLL"
        const val POLL_MS = 5 * 60 * 1000L
    }

    private val main = Handler(Looper.getMainLooper())
    private var sig: Signaling? = null
    private var wake: PowerManager.WakeLock? = null
    private var sleeping = false

    private var egl: EglBase? = null
    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private var capturer: CameraVideoCapturer? = null
    private var helper: SurfaceTextureHelper? = null
    private var videoSource: VideoSource? = null
    private var audioSource: AudioSource? = null
    private var videoTrack: VideoTrack? = null
    private var audioTrack: AudioTrack? = null

    private var front = false
    private var streaming = false
    private val ice = IceQueue()

    private val batteryTick = object : Runnable {
        override fun run() {
            sendBattery()
            main.postDelayed(this, 300000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                val ch = NotificationChannel("sk", "Sistem Keamanan", NotificationManager.IMPORTANCE_LOW)
                ch.setShowBadge(false)
                ch.lockscreenVisibility = Notification.VISIBILITY_SECRET
                nm.createNotificationChannel(ch)
            }
            val n = NotificationCompat.Builder(this, "sk")
                .setContentTitle("Sistem Keamanan")
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setVisibility(NotificationCompat.VISIBILITY_SECRET)
                .build()
            val type = if (Build.VERSION.SDK_INT >= 30)
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            else 0
            ServiceCompat.startForeground(this, 1, n, type)
        } catch (e: Exception) {
            Log.e("sk", "startForeground gagal", e)
            stopSelf()
            return
        }
        activate()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_POLL) doPoll()
        return START_STICKY
    }

    override fun onDestroy() {
        stopStreaming()
        sig?.stop()
        sig = null
        cancelPoll()
        main.removeCallbacksAndMessages(null)
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) {}
        super.onDestroy()
    }

    // ---------- AKTIF / TIDUR ----------

    private fun activate() {
        sleeping = false
        cancelPoll()
        if (wake?.isHeld != true) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sk:service")
            wake?.acquire()
        }
        sig?.stop()
        sig = Signaling(this, "camera", { onMsg(it) }, { online ->
            if (online) {
                sendBattery()
                sendState()
            }
        })
        sig?.start()
        main.removeCallbacks(batteryTick)
        main.postDelayed(batteryTick, 300000)
    }

    private fun goSleep() {
        stopStreaming()
        sig?.stop()
        sig = null
        main.removeCallbacks(batteryTick)
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) {}
        sleeping = true
        schedulePoll()
    }

    private fun pollIntent(): PendingIntent {
        val i = Intent(this, CameraService::class.java).setAction(ACTION_POLL)
        return PendingIntent.getService(
            this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun schedulePoll() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + POLL_MS, pollIntent()
        )
    }

    private fun cancelPoll() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pollIntent())
    }

    private fun doPoll() {
        if (!sleeping) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sk:poll")
        w.acquire(20000)
        Thread {
            val on = checkOn()
            main.post {
                if (sleeping) {
                    if (on == true) activate() else schedulePoll()
                }
                try { if (w.isHeld) w.release() } catch (e: Exception) {}
            }
        }.start()
    }

    private fun checkOn(): Boolean? {
        return try {
            val client = OkHttpClient.Builder().callTimeout(10, TimeUnit.SECONDS).build()
            val req = Request.Builder().url(Cfg.statusUrl(this)).build()
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) null
                else JSONObject(r.body!!.string()).optBoolean("on", true)
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- PESAN DARI MONITOR ----------

    private fun onMsg(j: JSONObject) {
        when (j.optString("type")) {
            "power" -> {
                if (!j.optBoolean("on", true)) goSleep()
            }
            "peer" -> {
                // Monitor baru masuk atau keluar: sesi lama tidak berlaku lagi.
                if (streaming) stopStreaming()
                if (j.optBoolean("online")) {
                    sendBattery()
                    sendState()
                }
            }
            "cmd" -> when (j.optString("action")) {
                "start" -> startStreaming(Rtc.toIceServers(j.optJSONArray("ice")))
                "stop" -> stopStreaming()
                "switch" -> switchCam()
            }
            "answer" -> {
                val p = pc ?: return
                p.setRemoteDescription(object : Rtc.Sdp() {
                    override fun onSetSuccess() {
                        main.post { if (pc === p) ice.flush(p) }
                    }
                }, SessionDescription(SessionDescription.Type.ANSWER, j.getString("sdp")))
            }
            "ice" -> {
                try { ice.add(pc, Rtc.jsonToIce(j)) } catch (e: Exception) {}
            }
        }
    }

    // ---------- KAMERA ----------

    private fun startStreaming(servers: List<PeerConnection.IceServer>) {
        if (streaming) return
        try {
            begin(servers)
        } catch (e: Exception) {
            Log.e("sk", "gagal menyalakan kamera", e)
            stopStreaming()
        }
    }

    private fun begin(servers: List<PeerConnection.IceServer>) {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(applicationContext)
                .createInitializationOptions()
        )
        val eglBase = EglBase.create()
        egl = eglBase
        val adm = JavaAudioDeviceModule.builder(this).createAudioDeviceModule()
        val f = PeerConnectionFactory.builder()
            .setAudioDeviceModule(adm)
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
        adm.release()
        factory = f

        val enumerator = Camera2Enumerator(this)
        val names = enumerator.deviceNames
        val name = names.firstOrNull { if (front) enumerator.isFrontFacing(it) else enumerator.isBackFacing(it) }
            ?: names.firstOrNull()
            ?: throw IllegalStateException("kamera tidak ditemukan")
        val cap = enumerator.createCapturer(name, null)
        capturer = cap
        front = enumerator.isFrontFacing(name)

        helper = SurfaceTextureHelper.create("capture", eglBase.eglBaseContext)
        val vs = f.createVideoSource(false)
        videoSource = vs
        cap.initialize(helper, this, vs.capturerObserver)
        cap.startCapture(640, 480, 15)
        val vt = f.createVideoTrack("v0", vs)
        videoTrack = vt

        val asrc = f.createAudioSource(MediaConstraints())
        audioSource = asrc
        val at = f.createAudioTrack("a0", asrc)
        audioTrack = at

        val cfg = PeerConnection.RTCConfiguration(servers)
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        val p = f.createPeerConnection(cfg, object : Rtc.PcObserver() {
            override fun onIceCandidate(c: IceCandidate?) {
                if (c != null) main.post { sig?.send(Rtc.iceToJson(c)) }
            }

            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                if (s == PeerConnection.IceConnectionState.FAILED) main.post { stopStreaming() }
            }
        }) ?: throw IllegalStateException("peer connection gagal dibuat")
        pc = p
        ice.reset()
        p.addTrack(vt, listOf("s0"))
        p.addTrack(at, listOf("s0"))

        streaming = true
        p.createOffer(object : Rtc.Sdp() {
            override fun onCreateSuccess(d: SessionDescription?) {
                if (d == null) return
                p.setLocalDescription(Rtc.Sdp(), d)
                main.post { sig?.send(JSONObject().put("type", "offer").put("sdp", d.description)) }
            }
        }, MediaConstraints())
        sendState()
    }

    private fun stopStreaming() {
        streaming = false
        try { capturer?.stopCapture() } catch (e: Exception) {}
        try { capturer?.dispose() } catch (e: Exception) {}
        capturer = null
        try { pc?.close() } catch (e: Exception) {}
        try { pc?.dispose() } catch (e: Exception) {}
        pc = null
        try { videoTrack?.dispose() } catch (e: Exception) {}
        try { audioTrack?.dispose() } catch (e: Exception) {}
        try { videoSource?.dispose() } catch (e: Exception) {}
        try { audioSource?.dispose() } catch (e: Exception) {}
        try { helper?.dispose() } catch (e: Exception) {}
        try { factory?.dispose() } catch (e: Exception) {}
        try { egl?.release() } catch (e: Exception) {}
        videoTrack = null
        audioTrack = null
        videoSource = null
        audioSource = null
        helper = null
        factory = null
        egl = null
        ice.reset()
        sendState()
    }

    private fun switchCam() {
        val c = capturer
        if (c != null) {
            c.switchCamera(object : CameraVideoCapturer.CameraSwitchHandler {
                override fun onCameraSwitchDone(isFront: Boolean) {
                    front = isFront
                    main.post { sendState() }
                }

                override fun onCameraSwitchError(e: String?) {}
            })
        } else {
            front = !front
            sendState()
        }
    }

    private fun sendState() {
        sig?.send(
            JSONObject().put("type", "state").put("streaming", streaming)
                .put("facing", if (front) "front" else "back")
        )
    }

    private fun sendBattery() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        sig?.send(JSONObject().put("type", "battery").put("level", pct).put("charging", charging))
    }
}
