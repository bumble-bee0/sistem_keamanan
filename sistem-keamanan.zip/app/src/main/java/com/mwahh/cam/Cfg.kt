package com.mwahh.cam

import android.content.Context
import java.net.URLEncoder
import java.util.UUID

object Cfg {
    const val HOST = "mwahh.mwahh.workers.dev"

    private fun prefs(c: Context) = c.getSharedPreferences("cam", Context.MODE_PRIVATE)

    fun code(c: Context): String = prefs(c).getString("code", "") ?: ""
    fun locked(c: Context): Boolean = prefs(c).getBoolean("locked", false) && code(c).isNotEmpty()

    // Kode baru disimpan HANYA setelah server menerimanya (lihat MainActivity).
    fun lock(c: Context, code: String) {
        prefs(c).edit().putString("code", code).putBoolean("locked", true).apply()
    }

    // Dipanggil kalau server mencabut/menolak pasangan ini. ID perangkat ikut dibuat ulang
    // supaya HP ini bisa dipasang lagi nanti dengan kode yang sama kalau pemilik menginginkannya.
    fun unlock(c: Context, notice: String) {
        prefs(c).edit()
            .remove("code")
            .putBoolean("locked", false)
            .remove("device")
            .putString("notice", notice)
            .apply()
    }

    fun resetDevice(c: Context) {
        prefs(c).edit().remove("device").apply()
    }

    // Pesan sekali tampil untuk layar masukan kode (misal "pasangan dilepas").
    fun takeNotice(c: Context): String {
        val n = prefs(c).getString("notice", "") ?: ""
        if (n.isNotEmpty()) prefs(c).edit().remove("notice").apply()
        return n
    }

    // ID unik HP ini, dibuat sekali. Server memakainya agar satu kode hanya dipakai satu HP.
    fun deviceId(c: Context): String {
        val saved = prefs(c).getString("device", null)
        if (!saved.isNullOrEmpty()) return saved
        val id = UUID.randomUUID().toString()
        prefs(c).edit().putString("device", id).apply()
        return id
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun claimUrl(c: Context, code: String) =
        "https://$HOST/claim?code=${enc(code)}&device=${enc(deviceId(c))}"

    fun wsUrl(c: Context) =
        "wss://$HOST/ws?code=${enc(code(c))}&role=camera&device=${enc(deviceId(c))}"

    fun statusUrl(c: Context) = "https://$HOST/status?code=${enc(code(c))}"
}
