package com.mwahh.cam

import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.*

object Rtc {

    open class Sdp : SdpObserver {
        override fun onCreateSuccess(d: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(e: String?) {}
        override fun onSetFailure(e: String?) {}
    }

    open class PcObserver : PeerConnection.Observer {
        override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
        override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {}
        override fun onIceConnectionReceivingChange(b: Boolean) {}
        override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
        override fun onIceCandidate(c: IceCandidate?) {}
        override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
        override fun onAddStream(s: MediaStream?) {}
        override fun onRemoveStream(s: MediaStream?) {}
        override fun onDataChannel(d: DataChannel?) {}
        override fun onRenegotiationNeeded() {}
    }

    fun cmd(action: String): JSONObject =
        JSONObject().put("type", "cmd").put("action", action)

    fun power(on: Boolean): JSONObject =
        JSONObject().put("type", "power").put("on", on)

    fun iceToJson(c: IceCandidate): JSONObject {
        val inner = JSONObject()
            .put("sdpMid", c.sdpMid)
            .put("sdpMLineIndex", c.sdpMLineIndex)
            .put("candidate", c.sdp)
        return JSONObject().put("type", "ice").put("candidate", inner)
    }

    fun jsonToIce(j: JSONObject): IceCandidate {
        val c = j.getJSONObject("candidate")
        val mid: String? = if (c.isNull("sdpMid")) null else c.getString("sdpMid")
        return IceCandidate(mid, c.getInt("sdpMLineIndex"), c.getString("candidate"))
    }

    // Ubah daftar ICE (JSON) menjadi objek IceServer. Kalau kosong/rusak, pakai STUN gratis.
    fun toIceServers(arr: JSONArray?): List<PeerConnection.IceServer> {
        val fallback = listOf(
            PeerConnection.IceServer.builder("stun:stun.cloudflare.com:3478").createIceServer()
        )
        if (arr == null) return fallback
        val out = ArrayList<PeerConnection.IceServer>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val u = o.opt("urls")
            val urls = ArrayList<String>()
            if (u is JSONArray) {
                for (k in 0 until u.length()) urls.add(u.getString(k))
            } else if (u is String) {
                urls.add(u)
            }
            if (urls.isEmpty()) continue
            val b = PeerConnection.IceServer.builder(urls)
            if (o.has("username")) b.setUsername(o.getString("username"))
            if (o.has("credential")) b.setPassword(o.getString("credential"))
            out.add(b.createIceServer())
        }
        return if (out.isEmpty()) fallback else out
    }
}

// Menampung kandidat ICE yang datang sebelum remote description terpasang.
class IceQueue {
    private val q = ArrayList<IceCandidate>()
    private var ready = false

    fun add(pc: PeerConnection?, c: IceCandidate) {
        if (ready && pc != null) pc.addIceCandidate(c) else q.add(c)
    }

    fun flush(pc: PeerConnection) {
        ready = true
        for (c in q) pc.addIceCandidate(c)
        q.clear()
    }

    fun reset() {
        q.clear()
        ready = false
    }
}
