package com.mwahh.cam

import android.app.Activity
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

// Activity transparan: memunculkan dialog izin tangkap-layar, lalu menyimpan hasilnya ke
// ScreenHolder dan langsung menutup diri. Bisa dipicu otomatis oleh CameraService (tanpa
// kamu buka aplikasinya) ketika izin sebelumnya sudah kedaluwarsa -- karena itu dibuat tampil
// di atas lock screen dan menyalakan layar sendiri, supaya InputService (Aksesibilitas) bisa
// langsung mencoba menyetujui dialognya secara otomatis.
class ScreenGrantActivity : AppCompatActivity() {

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK && r.data != null) {
            ScreenHolder.set(r.data!!)
            Toast.makeText(this, "Kontrol/pantau layar aktif.", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Dibatalkan, kontrol layar belum aktif.", Toast.LENGTH_SHORT).show()
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        launcher.launch(mgr.createScreenCaptureIntent())
        InputService.instance?.autoAcceptScreenDialog()
    }
}
